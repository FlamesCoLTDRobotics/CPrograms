
#include <stdio.h>
#include <stdlib.h>

int main()
{
    int player_hp = 100;
    int enemy_hp = 100;
    int player_attack = 10;
    int enemy_attack = 10;
    int player_defense = 5;
    int enemy_defense = 5;
    int player_magic = 15;
    int enemy_magic = 15;

    printf("Welcome to Super Mario RPG!\n");

    while (player_hp > 0 && enemy_hp > 0) {
        printf("Choose your action:\n1. Attack\n2. Defend\n3. Use Magic\n");
        int choice;
        scanf("%d", &choice);

        if (choice == 1) {
            enemy_hp -= (player_attack - enemy_defense);
            printf("You attacked the enemy and dealt %d damage!\n", (player_attack - enemy_defense));
        } else if (choice == 2) {
            player_defense += 5;
            printf("You defended and increased your defense by 5!\n");
        } else if (choice == 3) {
            enemy_hp -= (player_magic - enemy_defense);
            printf("You used magic and dealt %d damage!\n", (player_magic - enemy_defense));
        }

        if (enemy_hp > 0) {
            player_hp -= (enemy_attack - player_defense);
            printf("The enemy attacked you and dealt %d damage!\n", (enemy_attack - player_defense));
        }
    }

    if (player_hp <= 0) {
        printf("You have been defeated!\n");
    } else {
        printf("You have defeated the enemy!\n");
    }

    return 0;
}